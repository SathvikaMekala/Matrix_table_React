import React from "react";
import "./App.css";
import Matrix from "./components/Matrix";

function App() {
  return (
    <div className="App">
      <header>
        <h1></h1>
      </header>
      <main>
        <Matrix />
      </main>
    </div>
  );
}

export default App;
