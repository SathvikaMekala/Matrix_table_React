import React, { useState } from "react";
import Select from "react-select";
import "./TableGrid.css";

const options = {
  assign: [
    { value: "James", label: "James" },
    { value: "Linda", label: "Linda" },
    { value: "Jack", label: "Jack" },
    { value: "Rita", label: "Rita" },
    { value: "Ram", label: "Ram" },
  ],
  priority: [
    { value: "High", label: "High" },
    { value: "Medium", label: "Medium" },
    { value: "Low", label: "Low" },
  ],
  status: [
    { value: "Not Started", label: "Not Started" },
    { value: "Pending", label: "Pending" },
    { value: "In Progress", label: "In Progress" },
    { value: "Completed", label: "Completed" },
    { value: "Closed", label: "Closed" },
  ],
};
const Matrix = () => {
  const [columnHeader, setColumnHeader] = useState([]);
  const [rowHeader, setRowHeader] = useState([]);
  const handleHeader = (headerType, selectedOptions) => {
    const optionList = options[selectedOptions.value.toLowerCase()] || [];
    if (headerType === "column") {
      setColumnHeader(optionList);
    } else if (headerType === "row") {
      setRowHeader(optionList);
    }
  };
  return (
    <div className="matrix-table">
      <div className="headers">
        <div className="text">
          column Headers:
          <Select
            options={[
              { value: "assign", label: "assign" },
              { value: "priority", label: "priority" },
              { value: "status", label: "status" },
            ]}
            onChange={(selectedOption) =>
              handleHeader("column", selectedOption)
            }
            placeholder="Select Column Header"
          />
        </div>
        <div className="text-2">
          Row Headers :
          <Select
            options={[
              { value: "assign", label: "assign" },
              { value: "priority", label: "priority" },
              { value: "status", label: "status" },
            ]}
            onChange={(selectedOption) => handleHeader("row", selectedOption)}
            placeholder="Select Row Header"
          />
        </div>
      </div>
      <table className="table-container">
        <thead>
          <tr>
            <th></th>
            {columnHeader.map((header, index) => (
              <th key={index}>{header.label}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rowHeader.map((header, rowIndex) => (
            <tr key={rowIndex}>
              <td>{header.label}</td>
              {columnHeader.map((_, colIndex) => (
                <td key={colIndex}></td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default Matrix;
